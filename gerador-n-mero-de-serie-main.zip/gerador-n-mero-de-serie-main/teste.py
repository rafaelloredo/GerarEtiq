contagem = 'COMPRESSOR EMBRACO 1/4+ R134 220V'

print(len(contagem))